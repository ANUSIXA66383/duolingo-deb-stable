import toml
with open('/etc/duolingo/duolingo.toml') as f:
    config = toml.load(f)
duolingo = 'duolingo'

