#include <iostream>

int main() {
    std::string duolingo = "Duolingo";
    std::cout << duolingo << std::endl;
    return 0;
}